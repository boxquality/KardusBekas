import * as THREE from "three";

export function init3DScene(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  try {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(0, 1.1, 8.5);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    container.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffe2b2, 1.4));
    const key = new THREE.DirectionalLight(0xffd18a, 3.2);
    key.position.set(4, 6, 5); scene.add(key);
    const rim = new THREE.PointLight(0xb8782e, 35, 18);
    rim.position.set(-4, 1, -2); scene.add(rim);
    const fill = new THREE.PointLight(0xffe3b0, 14, 15);
    fill.position.set(2, -2, 4); scene.add(fill);

    const group = new THREE.Group();
    scene.add(group);

    function makeBox(w, h, d, x, y, z, rotation = 0) {
      const cardboard = new THREE.MeshStandardMaterial({ color: 0xa8753d, roughness: 0.88, metalness: 0.02 });
      const geometry = new THREE.BoxGeometry(w, h, d);
      const box = new THREE.Mesh(geometry, cardboard);
      box.position.set(x, y, z);
      box.rotation.y = rotation;
      box.castShadow = true;
      box.receiveShadow = true;
      group.add(box);

      const tapeMat = new THREE.MeshStandardMaterial({ color: 0xd7b578, roughness: 0.55 });
      const tape = new THREE.Mesh(new THREE.BoxGeometry(w * 0.13, h * 1.004, d * 1.006), tapeMat);
      tape.position.set(x, y, z);
      tape.rotation.y = rotation;
      group.add(tape);

      const edgeMat = new THREE.LineBasicMaterial({ color: 0x3a2614, transparent: true, opacity: 0.42 });
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(geometry), edgeMat);
      edges.position.copy(box.position);
      edges.rotation.copy(box.rotation);
      group.add(edges);

      // Flap-like top details make the package read clearly as a cardboard carton.
      const flapMat = new THREE.MeshStandardMaterial({ color: 0xb9864c, roughness: 0.9, side: THREE.DoubleSide });
      const flap = new THREE.Mesh(new THREE.BoxGeometry(w * 0.48, 0.035, d * 0.48), flapMat);
      flap.position.set(x, y + h / 2 + 0.025, z);
      flap.rotation.y = rotation;
      group.add(flap);
      return box;
    }

    makeBox(2.15, 1.65, 1.65, 0, 0, 0, -0.12);
    makeBox(0.72, 0.62, 0.72, -1.35, -1.05, -0.45, 0.35);
    makeBox(0.9, 0.72, 0.8, 1.28, 1.1, -0.7, -0.3);

    const ringGeo = new THREE.TorusGeometry(2.35, 0.008, 8, 120);
    const ring = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xc99a42, transparent: true, opacity: 0.48 }));
    ring.rotation.x = Math.PI * 0.38;
    ring.rotation.y = -0.2;
    group.add(ring);

    const particles = new THREE.Group();
    const particleMat = new THREE.MeshBasicMaterial({ color: 0xd6a34c });
    for (let i = 0; i < 34; i++) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.018 + Math.random() * 0.025, 6, 6), particleMat);
      p.position.set((Math.random() - .5) * 6, (Math.random() - .5) * 4, (Math.random() - .5) * 2);
      particles.add(p);
    }
    scene.add(particles);

    let pointerX = 0, pointerY = 0;
    container.addEventListener("pointermove", e => {
      const rect = container.getBoundingClientRect();
      pointerX = ((e.clientX - rect.left) / rect.width - .5) * 0.45;
      pointerY = ((e.clientY - rect.top) / rect.height - .5) * 0.25;
    }, { passive: true });
    container.addEventListener("pointerleave", () => { pointerX = 0; pointerY = 0; });

    const clock = new THREE.Clock();
    let frame = 0;
    function render() {
      frame = requestAnimationFrame(render);
      const t = clock.getElapsedTime();
      group.rotation.y += (pointerX + Math.sin(t * 0.28) * 0.12 - group.rotation.y) * 0.025;
      group.rotation.x += (pointerY + Math.sin(t * 0.4) * 0.035 - group.rotation.x) * 0.025;
      group.position.y = Math.sin(t * 0.8) * 0.12;
      ring.rotation.z = t * 0.12;
      particles.rotation.y = t * 0.035;
      renderer.render(scene, camera);
    }
    render();

    const resize = () => {
      const w = container.clientWidth || 1;
      const h = container.clientHeight || 1;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    window.addEventListener("beforeunload", () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      renderer.dispose();
    }, { once: true });
  } catch (error) {
    console.error("BOXQUALITY 3D scene failed:", error);
    container.innerHTML = '<div class="webgl-fallback">BOXQUALITY / 3D EXPERIENCE</div>';
  }
}